package com.cg.payroll.client;
import java.util.Scanner;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args) throws AssociateDetailsNotFoundException{
		PayrollServices services=new PayrollServicesImpl();
		double netSalary;
		double grossSalary;
		double empTax;
		Scanner sc=new Scanner(System.in);
		int associateId=services.acceptAssociateDetails("nilotpal", "majumdar", "kutan16@gmail.com", "IT", "Analyst", "dfg4gf", 20000, 12000, 1800, 1800, 3793, "sbi", "sbin00584");
		System.out.println("Associate Id:- "+associateId);
		int associateId2=services.acceptAssociateDetails("kutan", "lock", "lock@gmail.com", "IT", "Analyst", "htrhb", 20000, 12000, 1800, 1800, 8064, "axis", "axis00023");
		System.out.println("Associate Id:- "+associateId2);
	int choice;
	while(true) {
		System.out.println("Enter your choice");
	
		System.out.println("1. get associate details");
		System.out.println("2. get salary details");
		System.out.println("3. To Exit");
		choice = sc.nextInt();
		switch(choice) {
		case 1:
			System.out.println("Enter the employee id you want to search: ");
			int num=sc.nextInt();
			System.out.println(services.getAssociateDetails(num));
			break;
		case 2:
			System.out.println("Enter associate Id to get salary details : ");
			int sal = sc.nextInt();
			System.out.println("Enter The ComapanyPf");
			double companyPf=sc.nextDouble();
			System.out.println("Enter The epf");
			double epf=sc.nextDouble();
			
			System.out.println("------------");
			try {
			if(sal==101) {
				netSalary=services.calculateNetSalary(associateId);
				grossSalary=services.calculateAnnualGrossSalary(associateId);
				System.out.println("Net Salary for EmpId "+ associateId+" is "+netSalary);
				System.out.println("Annual GrossSalary for EmpId "+associateId+" is "+grossSalary);
				empTax=services.taxCalculator(netSalary,epf,companyPf);
				System.out.println("Tax of EmpId "+associateId+" is "+empTax);
			}
			else if(sal==102) {
				netSalary=services.calculateNetSalary(associateId2);
				grossSalary=services.calculateAnnualGrossSalary(associateId2);
				System.out.println("Net Salary for EmpId "+ associateId2+" is "+netSalary);
				System.out.println("Annual GrossSalary for EmpId "+associateId2+" is "+grossSalary);
				empTax=services.taxCalculator(netSalary,epf,companyPf);
				System.out.println("Tax of EmpId "+associateId+" is "+empTax);
			}
			else
				System.out.println("AssociateDetail Not Found");
			}
			catch(AssociateDetailsNotFoundException e)
			{
				
				e.printStackTrace();
			}
			break;
		case 3: System.exit(0);
		default:System.out.println("Oopss!!!!!Wrong Choice");
		}
	}
	}
}