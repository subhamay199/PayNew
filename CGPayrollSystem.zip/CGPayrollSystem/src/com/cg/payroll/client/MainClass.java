package com.cg.payroll.client;

import java.util.Scanner;

import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass
{
	public static double taxCalculator(double netSalary,double epf,double companypf) {
		double grossSal=netSalary+epf+companypf;
		if(grossSal<=250000)
			return 0;
		else if(grossSal>250000&& grossSal<=500000)
		{
			grossSal-=250000;
			return grossSal/10;
		}
		else if(grossSal>500000&& grossSal<=1000000)
		{
			grossSal-=500000;
			return grossSal/5+25000;
		}
		else 
		{
			grossSal-=1000000;
			return (grossSal*3/10)+50000+25000;
		}
	}
	public static void main(String[] args) throws AssociateDetailNotFoundException 
	{
		PayrollServices services=new PayrollServicesImpl();
		Scanner sc=new Scanner(System.in);
		int associateId=services.acceptAssociateDetails("Satish","mahajan","satish@gmail.com","ytp","Sr Cont.","101",15122,40000,5,32,12,"Axis","ds15");
		System.out.println("AssociateId: - "+associateId);
	//	System.out.println(services.calculateNetSalary(associateId));
		System.out.println("Enter pf");
		int pf=sc.nextInt();
		System.out.println("Enter CompanyPf");
		int pf1=sc.nextInt();
		System.out.println("Enter Basic Salary");
		int bs=sc.nextInt();
		double netSalary=services.calculateNetSalary(bs,pf,pf1);
		System.out.println(netSalary);
		System.out.println("Monthly NetSalary Is: "+netSalary/12);
		System.out.println("Taxable Amount Is: "+taxCalculator(bs,pf,pf1));
	}
}
