package com.cg.payroll.test;

import static org.junit.Assert.*;
import java.util.ArrayList;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class PayrollServicesTestEasyMock {
	private static PayrollServices payrollServices;
	private static AssociateDAO mockAssociateDao;

	@BeforeClass
	public static void setUpTestEnv() {
		mockAssociateDao=EasyMock.mock(AssociateDAO.class);
		payrollServices=new PayrollServicesImpl(mockAssociateDao);
	}

	@Before
	public void setUpTestMockData() {
		Associate associate1=new Associate(101,20000,"nilotpal","majumdar","java","intern","asd23232","kutan16@gmail.com",new Salary(12000,1800,1800),new BankDetails(12345, "sbi", "sbin00083"));
		Associate associate2=new Associate(102,10000,"lock","key","java","intern","asd32323","lock@gmail.com",new Salary(12000,1800,1800),new BankDetails(12345, "sbi", "sbin00083"));
		Associate associate3=new Associate(103,5000,"sen","kuro","java","intern","asd32323","kurosen@gmail.com",new Salary(12000,1800,1800),new BankDetails(12345, "sbi", "sbin00083"));
		ArrayList<Associate>associatesList=new ArrayList<Associate>();
		associatesList.add(associate1);
		associatesList.add(associate2);
		EasyMock.expect(mockAssociateDao.save(associate3)).andReturn(associate3);
		
		EasyMock.expect(mockAssociateDao.findOne(101)).andReturn(associate1);
		EasyMock.expect(mockAssociateDao.findOne(102)).andReturn(associate2);
		EasyMock.expect(mockAssociateDao.findOne(1234)).andReturn(null);
		EasyMock.expect(mockAssociateDao.findAll()).andReturn(associatesList);
		EasyMock.replay(mockAssociateDao);
	}
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDataForInvalidAssociateId() throws AssociateDetailsNotFoundException {
		payrollServices.getAssociateDetails(1234);
		EasyMock.verify(mockAssociateDao.findOne(1234));
	}
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDataForValidAssociateId() throws AssociateDetailsNotFoundException {
		Associate expectedAssociate = new Associate(101,20000,"nilotpal","majumdar","java","intern","asd23232","kutan16@gmail.com",new Salary(12000,1800,1800),new BankDetails(12345, "sbi", "sbin00083"));
		//expectedAssociate.setAssociateId(101);
		Associate actualAssociate=payrollServices.getAssociateDetails(101);
		assertEquals(expectedAssociate, actualAssociate);
		EasyMock.verify(mockAssociateDao.findOne(101));
	}
	
	@After
	public void tearDownTestMockData() {
		EasyMock.resetToDefault(mockAssociateDao);
	}
	
	@AfterClass
	public static void tearDownTestEnv() {
		mockAssociateDao=null;
		payrollServices=null;
	}
}
