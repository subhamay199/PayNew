
public class MainClass {

	public static void main(String[] args) {
		
		int num=100;
		Integer ib=num;
		System.out.println(ib);
		System.out.println(ib.equals(100));
		
		Integer iob=100;
		int n=iob;
		//System.out.println(iob.equals(n));


	}

}
