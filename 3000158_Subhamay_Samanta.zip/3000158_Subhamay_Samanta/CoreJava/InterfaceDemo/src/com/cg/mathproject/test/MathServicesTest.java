package com.cg.mathproject.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mathproject.exception.NegativeNumberException;
import com.cg.mathproject.exceptions.InvalidNumberRangeException;
import com.cg.mathproject.services.MathServices;
import com.cg.mathproject.services.MathServicesImpl;

//import junit.framework.Assert;

public class MathServicesTest {
	private static MathServices services;
	@BeforeClass
public static void setUpTestEnv() {
		services=new MathServicesImpl();	
}
@Test(expected=NegativeNumberException.class)
public void testAddForFirstNumberInvalid() throws  NegativeNumberException{
	services.add(-100,200);
}
@Test(expected=NegativeNumberException.class)
public void testAddForSecondNumberInvalid() throws  NegativeNumberException{
	services.add(100,-200);
}
@Test
public void testAddForBothNumberInvalid() throws  NegativeNumberException{
	Assert.assertEquals(300, services.add(100,200));
}
@Test(expected=NegativeNumberException.class)
public void testSubtractForFirstNumberInvalid() throws  NegativeNumberException{
	services.add(-100,200);
}
@Test(expected=NegativeNumberException.class)
public void testSubtractForSecondNumberInvalid() throws  NegativeNumberException{
	services.add(100,-200);
}
@Test
public void testSubtractForBothNumberInvalid() throws  NegativeNumberException{
	Assert.assertEquals(-100, services.sub(100,200));
}
@AfterClass
public static void tearDownTestEnv() {
		services=null;	
}
}
