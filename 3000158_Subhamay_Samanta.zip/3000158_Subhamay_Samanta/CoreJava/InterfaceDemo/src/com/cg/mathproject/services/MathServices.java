package com.cg.mathproject.services;

import com.cg.mathproject.exception.NegativeNumberException;

public interface MathServices {
	public int add(int n1,int n2) throws NegativeNumberException;
	abstract int sub(int n1,int n2)  throws NegativeNumberException;
	public abstract int div(int n1,int n2)  throws NegativeNumberException;
	int multi(int n1,int n2)  throws NegativeNumberException;

}
