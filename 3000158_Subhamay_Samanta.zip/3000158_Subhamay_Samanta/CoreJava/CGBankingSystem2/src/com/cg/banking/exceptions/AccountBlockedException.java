package com.cg.banking.exceptions;

public class AccountBlockedException extends Exception{

	
}
