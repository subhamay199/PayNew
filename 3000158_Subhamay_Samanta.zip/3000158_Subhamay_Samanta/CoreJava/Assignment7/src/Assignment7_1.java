public class Assignment7_1 
{
	public static void getSorted(int a[])
	{
		int n=a.length;
		int[] b=new int[n];
		int j=n;
		for(int i=0;i<n;i++)
		{
			b[j-1]=a[i];
			j--;
		}
		Arrays.sort(a);
	}
	public static void main(String[] args) 
	{
		int[] a={10,5,8,1,4};
		getSorted(a);
		int n=a.length;
		for(int k=0;k<n;k++)
		{
			System.out.print(a[k]+" ");
		}
 		
	}

}
