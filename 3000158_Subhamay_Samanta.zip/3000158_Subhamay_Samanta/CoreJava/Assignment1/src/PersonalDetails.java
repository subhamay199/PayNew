
public class PersonalDetails 
{
	public static void main(String[] args) 
	{
		String fn,ln;
		char gen;
		int age;
		float wt;
		fn="Divya";
		ln="Bharathi";
		gen='F';
		age=20;
		wt=85.5f;
		System.out.println("Personal Details:");
		System.out.println("_________________");
		System.out.println("First Name: "+fn);
		System.out.println("Last Name: "+ln);
		System.out.println("Gender: "+gen);
		System.out.println("Age: "+age);
		System.out.println("Weight: "+wt);

	}

}
