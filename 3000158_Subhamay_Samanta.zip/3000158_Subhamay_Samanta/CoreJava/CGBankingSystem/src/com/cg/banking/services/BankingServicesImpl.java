package com.cg.banking.services;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;


public class BankingServicesImpl implements BankingServices{

	private AccountDAO accountDAO = new AccountDAOImpl();

	//TransactionDAO transaction=new TransactionDAOImpl();
	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account account=new Account(accountType,initBalance);
		account=accountDAO.save(account);
		return account;
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account=new Account(accountNo,amount);
		accountDAO.update(account);
		return amount;
	}

	@Override
	public float withdrawAmount(long AccountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAccountTypeException {
		Account account;
		account = accountDAO.findOne(AccountNo);
		float f=account.getAccountBalance();
		if(pinNumber==account.getPinNumber())
				f=f-amount;
		// account=new Account(AccountNo,f,pinNumber);
		else 		throw new InvalidAccountTypeException();
			//Account accountNo=
		return f;
	}
	@Override
	public boolean fundTransfer(long accountNoTo, long accountNoForm, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException, InvalidAccountTypeException{	
		Account account = null;
		if(pinNumber==account.getPinNumber()) {
		withdrawAmount(accountNoForm, transferAmount, pinNumber);
		depositAmount(accountNoTo, transferAmount);
		}
		else
			throw new InvalidAccountTypeException();
		return false;
}
	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
			
		Account account=accountDAO.findOne(accountNo);
		if(account==null)
			throw new AccountNotFoundException("Associate details Not Found for Id"+accountNo);
		return account;
		
	}

	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {

		return accountDAO.findAll();
	}

	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
	
		
		return null;
	}

	@Override
	public String acoountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		// TODO Auto-generated method stub
		return null;
	}
}
