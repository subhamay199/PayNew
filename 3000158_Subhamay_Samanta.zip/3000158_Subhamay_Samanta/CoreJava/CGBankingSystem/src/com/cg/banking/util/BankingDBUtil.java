package com.cg.banking.util;

import java.util.HashMap;

import com.cg.banking.beans.Account;

public class BankingDBUtil {
	public static HashMap<Integer,Account> accounts=new HashMap<>();
	private static int Account_ID_COUNTER=100;
	
	public static int getAccount_ID_COUNTER() {
		return ++Account_ID_COUNTER;
}
	
	private int pinNumber=(int) (Math.random()*1000);
	public int getPinNumber()
	{
		return pinNumber;
	}
}
