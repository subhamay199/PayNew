package com.cg.project.threadwork;

public class RunnableResource implements Runnable {

	
	@Override
	public void run() {
			Thread t=Thread.currentThread();
			//int n=5;
			for(int i=1;i<=10;i++)
			{if(i%2==0)
		//	if(t.getName().equals("TickThread"))
				//for(int i=1;i<=10;i++)
					System.out.println("Even  "+i+"  "+t.getName());
			else
				//(t.getName().equals("TockThread"))
			//	for(int i=1;i<=10;i++)
					System.out.println("Odd   "+i+"  "+t.getName());}
		System.out.println("End Of Thread Task");
		
	
		
		
	}
	

}
