package com.cg.project.collections;

import java.util.HashSet;

public class SetClassesDemo {
	public static void hasSetClassDemo() {
		HashSet<Associate> associates=new HashSet<>();
		associates.add(new Associate(111,"Satish","Mahajan",15000));
		associates.add(new Associate(114,"Kumar","Raj",44222));
		associates.add(new Associate(111,"Ayush","Patil",17980));
		
		associates.add(new Associate(111,"Mayur","Patil",13299));
		associates.add(new Associate(111,"Nilesh","Kumar",84259));
	}

}
