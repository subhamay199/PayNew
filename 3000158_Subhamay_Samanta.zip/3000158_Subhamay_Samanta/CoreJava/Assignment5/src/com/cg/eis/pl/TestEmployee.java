package com.cg.eis.pl;
import java.util.Scanner;
import com.cg.eis.bean.*;
import com.cg.eis.service.*;

public class TestEmployee 
{
	public static void main(String[] args) 
	{
		int id;
		int choice;
		String name;
		double salary;
		Designation designation=null;
		Insurance insurancescheme;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter The No. Of The EWmployees");
		int n=sc.nextInt();
		EmployeeInsuranceSystemService emp=new EmployeeInsuranceSystemService(n);
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter The Id: ");
			id=sc.nextInt();
			System.out.println("Enter The Employee Name: ");
			name=sc.next();
			System.out.println("Enter The Salary: ");
			salary=sc.nextDouble();
			System.out.println("Enter The Designation: ");
			System.out.println("Enter Your Choice: "+"\n"+"1.SystemAssociate 2.Programmer  3. Manager  4. Clerk");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:	designation=Designation.SystemAssociate;break;
			case 2: designation=Designation.Programmer;break;
			case 3:	designation=Designation.Manager;break;
			case 4:	designation=Designation.Clerk;break;
			}
			insurancescheme=emp.showInsuranceSchemes(id,salary,designation);
			emp.addEmployeeDetails(id, name, salary, designation, insurancescheme);
		}
		System.out.println("Employee details: ");
		for(int i=0;i<n;i++)
		{
			emp.disEmployeeDeatils(i);
		}
	}
}