package com.cg.payroll.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;
	//import com.cg.mathproject.services.MathServicesImpl;
public class PayrollServicesTest {
	private static PayrollServices services;
	@BeforeClass
	public static void setUpTestEnv() {
			services=new PayrollServicesImpl();	
	}
	@Before
	public void setUpTestData() {
	Associate associate1=new Associate(101, 78000,"Satish","Mahajan","Training","Manager","DTDYF122","satish.mahajan@capgemini.com",new BankDetails(12345,"HDFC","fdg"),new Salary(35000,1800,1800));
	Associate associate2=new Associate(102, 48000,"Dmk","M","Training","Manager","DLTDYF122","satish@capgemini.com",new BankDetails(125,"HDFC","fdg"),new Salary(30500,2800,1000));
	PayrollDBUtil.associates.put(associate1.getAssociateId(),associate1);
	PayrollDBUtil.associates.put(associate2.getAssociateId(),associate2);
	PayrollDBUtil.ASSOCIATE_ID_COUNTER=102;
	}
	@Before
	public void tearDownTestData() {
	PayrollDBUtil.associates.clear();
	PayrollDBUtil.ASSOCIATE_ID_COUNTER=100;
	}
	@Test(expected=AssociateDetailNotFoundException.class)
	public void testGetAssociateDetailsForInvalidAssociateId() throws AssociateDetailNotFoundException {
		services.getAssociateDetails(12254);
	}
	@Test(expected=AssociateDetailNotFoundException.class)
	public void testGetAssociateDetailsForValidAssociateId() throws AssociateDetailNotFoundException {
	Associate expectedAssociate=new Associate(102, 48000,"mk","M","Training","Manager","DLTDYF122","satish@capgemini.com",new BankDetails(125,"HDFC","fdg"),new Salary(30500,2800,1000));
	Associate actualAssociate=services.getAssociateDetails(102);
	Assert.assertEquals(expectedAssociate, actualAssociate);
	}
	@Test(expected=AssociateDetailNotFoundException.class)
	public void testAcceptAssociateDetailsForValidAssociateId() throws AssociateDetailNotFoundException {
		int expectedId=103;
		int actualId=services.acceptAssociateDetails("AB", "cd", "abc@xy", "department", "designation", "pancard", 100, 200, 10, 20, 12345, "bankName", "ifscCode");
		Assert.assertEquals(expectedId, actualId);
	}
	@Test(expected =AssociateDetailNotFoundException.class)
	public void testCalculateNetSalaryForInvalidAssociateId() throws AssociateDetailNotFoundException{
		services.calculateNetSalary(1434,1200,1000);
	}
	@Test
	public void testCalculateNetSalaryForValidAssociateId() throws AssociateDetailNotFoundException{
	int expectedNetSalary=0;
	double actualNetSalary=services.calculateNetSalary(102,1200,1000);
	Assert.assertEquals(expectedNetSalary, actualNetSalary);
	}	
	@AfterClass
	public static void tearDownTestEnv() {
		services=null;	
}
}
