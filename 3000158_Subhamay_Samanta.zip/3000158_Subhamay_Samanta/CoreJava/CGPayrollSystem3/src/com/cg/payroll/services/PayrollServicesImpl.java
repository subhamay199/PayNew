package com.cg.payroll.services;

import java.util.ArrayList;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailNotFoundException;

public class PayrollServicesImpl implements PayrollServices{

	private AssociateDAO associateDAO;
	public PayrollServicesImpl() {
		 associateDAO=new AssociateDAOImpl();
	}
	public PayrollServicesImpl(AssociateDAO associateDAO) {
		super();
		 this.associateDAO=associateDAO;
	}
	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder8oC, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) {
		Salary salary=new Salary(basicSalary,epf,companyPf);
		BankDetails bankDetails=new BankDetails(accountNumber,bankName,ifscCode);
		Associate associate=new Associate(yearlyInvestmentUnder8oC, firstName, lastName, department, designation, pancard, emailId,bankDetails,salary);
		associate=associateDAO.save(associate);
		return associate.getAssociateId();
	}

	public double calculateNetSalary(int basicSalary,int epf,int companyPf) throws AssociateDetailNotFoundException {
/*		
	Associate associate=getAssociateDetails(associateId);
		Salary salary = null;
		salary.hra=;
		double s=salary.getBasicSalary()+(salary.getBasicSalary()*30/100)+ (salary.getBasicSalary()*30/100)+ (salary.getBasicSalary()*25/100)+ (salary.getBasicSalary()*20/100);
		s=s-24000;
		return s;
		double hra=basic*/
		double netSalary=basicSalary-epf-companyPf;
		double hra=basicSalary*3/10;
		double ca=basicSalary*3/10;
		double otherAllowance=basicSalary*1/4;
		double pa=basicSalary*1/5;
		netSalary+=hra+ca+otherAllowance+pa;
		System.out.println(pa);
		return netSalary;
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailNotFoundException {
		Associate associate=associateDAO.findOne(associateId);
		if(associate==null)
			throw new AssociateDetailNotFoundException("Associate details Not Found for Id"+associateId);
		return associate;
	}

	@Override
	public List<Associate> getAllAssociatesDetails() {
		return associateDAO.findAll();	}

}
