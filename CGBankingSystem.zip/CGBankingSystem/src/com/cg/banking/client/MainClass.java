package com.cg.banking.client;
import java.util.Scanner;
import com.cg.banking.beans.Account;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
public class MainClass {
	public static void main(String[] args) {
		int accountNumber;
		int pinNumber;
		int amount;
		int choice;
		BankingServices bankingService =new BankingServicesImpl();
		Account account1=null;
		Account account2=null;
		Scanner sc=new Scanner(System.in);
		while(true) {
			System.out.println("Press 1 For Creating Account");
			System.out.println("Press 2 For Withdraw From Account");
			System.out.println("Press 3  For Deposit into Account");
			System.out.println("Press 4 For Fund Transfer between Account");
			System.out.println("Press 5 For Exit");
			choice=sc.nextInt();
			switch(choice) {
			case 1: account1=bankingService.openAccount("Savings", 2000);
							account1.setAccountStatus("Active");
								account2=bankingService.openAccount("Savings", 9000);
									account2.setAccountStatus("Active");
										System.out.println("Account Details:\n "+account1);
											System.out.println("Account Details:\n "+account2);
								break;
										
			case 2: 				
								System.out.println("Enter account number from which amount is to be withdrawn: ");
								accountNumber=sc.nextInt();
								System.out.println("Enter pin number: ");
								pinNumber=sc.nextInt();
								System.out.println("Enter amount to be withdrawn:");
								amount=sc.nextInt();
								bankingService.withdrawAmount(accountNumber, amount, pinNumber);
								System.out.println("Account details after withdrawal: "+bankingService.getAccountDetails(accountNumber));
								break;
			case 3: 	
							System.out.println("Enter account number from which amount is to be deposited: ");
								accountNumber=sc.nextInt();
								System.out.println("Enter amount to be deposited:");
								amount=sc.nextInt();
								bankingService.depositAmount(accountNumber, amount);
								System.out.println("Account details after depositing: "+bankingService.getAccountDetails(accountNumber));
								break;
			case 4:		
									System.out.println("Enter the account number from which money will be transferrred: ");
									int accountNoFrom=sc.nextInt();
									System.out.println("Enter the Pin Number: ");
									pinNumber=sc.nextInt();
									System.out.println("Enter the account number where money will be transferred: ");
										int accountNoTo=sc.nextInt();
										System.out.println("Enter amount: ");
										float transferAmount=sc.nextInt();
										boolean b=bankingService.fundTransfer(accountNoTo, accountNoFrom, transferAmount, pinNumber);
										if(b) {
											System.out.println("Account Status of Depositor:\n"+bankingService.getAccountDetails(accountNoFrom));
											System.out.println("Account Status of Reciever:\n"+bankingService.getAccountDetails(accountNoTo));
										}
										break;
			case 5: System.exit(0);
			default:System.out.println("Oops!!!!Wrong Choice");
			}
		}
	}
}